
import pandas as pd
import numpy as np

def compute_risk_score(df: pd.DataFrame) -> pd.DataFrame:
    """Compute normalized absences, inverted grade and risk score (0–100)."""
    df = df.copy()

    # Normalize absences
    min_abs = df['Absences'].min()
    max_abs = df['Absences'].max()
    if max_abs > min_abs:
        df['absences_norm'] = (df['Absences'] - min_abs) / (max_abs - min_abs)
    else:
        df['absences_norm'] = 0

    # Normalize grades and invert
    min_grade = df['AverageGrade'].min()
    max_grade = df['AverageGrade'].max()
    if max_grade > min_grade:
        df['grade_norm_inv'] = 1 - ((df['AverageGrade'] - min_grade) / (max_grade - min_grade))
    else:
        df['grade_norm_inv'] = 0

    # Combined risk score
    df['risk_score'] = (100 * (0.5 * df['absences_norm'] + 0.5 * df['grade_norm_inv'])).round().astype(int)
    df['risk_level'] = df['risk_score'].apply(classify_risk_level)
    return df

def classify_risk_level(score: int) -> str:
    """Classify risk level based on the score."""
    if score >= 70:
        return "High"
    elif score >= 40:
        return "Medium"
    else:
        return "Low"
